$(document).ready(function() {
	$("#wikiContent>div").dblclick(function() {                  
		//alert(this.innerHTML);
		$("#wikiContent>div").select();
		/*
		if ($.browser.msie) { 
			var range = document.body.createTextRange(); 
			range.moveToElementText(text); 
			range.select(); 
		} else if ($.browser.mozilla || $.browser.opera) { 
			var selection = window.getSelection(); 
			var range = document.createRange(); 
			//range.selectNodeContents(text); 
			selection.removeAllRanges(); 
			selection.addRange(range); 
		} else if ($.browser.safari) { 
			var selection = window.getSelection(); 
			selection.setBaseAndExtent(text, 0, text, 1); 
		} */
	}); 
});

function openHelpBox() {
	window.open('/r1/helpBox.html', 'help', 'toolbar=0,location=0,status=0,menubar=0,scrollbars=1,resizable=0,width=600,height=720');
}