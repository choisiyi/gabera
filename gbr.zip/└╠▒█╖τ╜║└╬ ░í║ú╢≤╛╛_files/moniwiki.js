_translations = {
"Save":
   "저장",
"Preview":
   "미리보기",
"Cancel":
   "취소",
"Bold (Ctrl+b)":
   "굵게 (Ctrl-b)",
"Italic (Ctrl+i)":
   "기울임 (Ctrl+i)",
"Underline (Ctrl+u)":
   "밑줄 (Ctrl+u)",
"Strike Through (Ctrl+d)":
   "삭제선 (Ctrl+d)",
"Horizontal Rule":
   "수평줄",
"Numbered List":
   "숫자 리스트",
"Bulleted List":
   "총알 리스트",
"More Indented":
   "들여쓰기",
"Less Indented":
   "내어쓰기",
"About Wikiwyg":
   "Wikiwyg는",
"Normal Text":
   "일반 글씨",
"Heading 1":
   "제목 1",
"Heading 2":
   "제목 2",
"Heading 3":
   "제목 3",
"Heading 4":
   "제목 4",
"Heading 5":
   "제목 5",
"Heading 6":
   "제목 6",
"Create Link":
   "링크 생성",
"Smiley":
   "스마일리",
"Remove Linkedness":
   "링크 제거",
"Create Table":
   "테이블",
"Math":
   "수식",
"As Is":
   "그대로",
"Image":
   "이미지",
"Media":
   "미디어",
"Quote":
   "인용",
"Continue to edit current text ?":
   "현재의 텍스트를 계속 편집하시겠습니까 ?",
"Canceled!":
   "취소되었습니다!",
"Please select the text you would like to turn into a link.":
   "링크로 바꾸고 싶은 텍스트를 선택해주시기 바랍니다.",
"Auto saved text found.\nAre you sure to restore page ?\n(You can undo/redo with Ctrl-Z/Ctrl-Shift-Z)":
   "자동 저장된 텍스트가 있습니다.\n저장된 것으로 편집하시겠습니까 ?\n(Ctrl-Z/Ctrl-Shift-Z를 누르시면 undo/redo를 하실 수 있습니다)",
"Current text is saved in a temporary file.":
   "텍스트가 보존되었습니다.",
"The code is in your clipboard now":
   "코드가 클립보드로 복사되었습니다",
"Printing...":
   "인쇄중...",
"copy to clipboard":
   "클립보드 복사",
"view plain":
   "텍스트 보기",
"Toggle line numbers":
   "줄 번호 토글"
}

